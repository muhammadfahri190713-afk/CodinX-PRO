#!/usr/bin/env bash
# CodinX installer — root only. Memasang ke /opt/codinx dan membuat perintah `codinx`.
set -e
[ "$(id -u)" = "0" ] || { echo "CodinX hanya untuk root. Jalankan sebagai root."; exit 1; }
command -v python3 >/dev/null || { echo "python3 tidak ditemukan (butuh >= 3.9)."; exit 1; }
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)' || { echo "Butuh Python >= 3.9"; exit 1; }

SRC="$(cd "$(dirname "$0")" && pwd)"
DEST=/opt/codinx
if [ "$SRC" != "$DEST" ]; then
  mkdir -p "$DEST"
  cp -a "$SRC"/. "$DEST"/
  # seed berisi kunci plaintext: hapus dari folder sumber setelah disalin (akan diimpor ke brankas saat run pertama)
  if [ -f "$SRC/.seed" ]; then
    python3 - "$SRC/.seed" <<'PY'
import os, sys
p = sys.argv[1]
n = os.path.getsize(p)
open(p, "r+b").write(os.urandom(n))
os.remove(p)
PY
  fi
fi
chmod +x "$DEST/bin/codinx"
[ -f "$DEST/.env" ] && chmod 600 "$DEST/.env"
ln -sf "$DEST/bin/codinx" /usr/local/bin/codinx
mkdir -p /root/.codinx/skills /root/.codinx/commands
chmod 700 /root/.codinx
echo "✓ CodinX terpasang. Jalankan:  codinx"

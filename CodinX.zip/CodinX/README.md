# CodinX — agent coding di terminal (khusus root)

Agent coding berbasis terminal, terinspirasi opencode, Codex CLI, dan Claude Code.
Python murni (stdlib), tanpa dependensi. Hanya jalan sebagai **root** (`root@localhost` atau `root@host` lain).

## Jalankan
    unzip CodinX.zip && cd CodinX
    npm run -s codinx-agents          # atau: python3 bin/codinx
    # opsional, pasang permanen:  bash install.sh   →  ketik: codinx

Run pertama: file `.seed` (endpoint + API key) otomatis diimpor ke brankas terenkripsi
`~/.codinx/.key.enc` (tersembunyi, mode 600), lalu `.seed` ditimpa & dihapus.
Endpoint bawaan: `https://inttelix.vercel.app/api/v1`. Ganti kapan saja dengan `/connect`.

Non-interaktif: `codinx run "buat web todo" --auto` · `codinx run -c "lanjutkan"` · `--format json` · `--plan`

## Fitur
- **Banner + UI berwarna**: Markdown dirender (judul, bold, kode, bullet, **tabel**), 11 tema (`/theme`).
- **Tools**: read, write, edit, list, glob, grep, bash (+background), webfetch (web & `localhost:3000`),
  todowrite, task (sub-agent), skill, memory, table (+simpan .csv/.md/.json), camera.
- **Izin (kuning)**: tiap tool sensitif bertanya *"Apakah anda ingin izinkan ini?"* → **Iya / Tidak / Selalu izinkan**
  (←/→ + Enter, atau tombol i/t/s). Jika *Tidak*, agent otomatis mencoba cara/tool lain.
  *Selalu izinkan* = tool itu bebas dipakai (tersimpan). Perintah destruktif (`rm -rf /`, `mkfs`, `dd of=/dev/…`, reboot…) **selalu diblokir**.
- **/permissions**: tombol pengaturan per tool (bawaan → tanya → izinkan → tolak → mati): terminal, file, web, localhost, kamera, dll.
- **Memori**: sesi tersimpan otomatis (1 percakapan = 1 id, dikirim sebagai `X-Conversation-Id` + `user`), folder yang sama otomatis
  melanjutkan sesi terakhir. Memori jangka panjang lewat tool `memory` / `/memory`. Konteks auto-compact.
- **Skills** (`SKILL.md`): 10 bawaan + `~/.codinx/skills/` + `.codinx/skills/`. **Perintah custom** (`commands/*.md`, `$ARGUMENTS`, `` !`cmd` ``, `@file`).
- Mode **build/plan** (`/plan`, `/build`), `/undo` `/redo`, `/init` (AGENTS.md), `@file`, `!shell`, `/export`, `/share` (lokal).

## Paket & Dinar
| Paket | Model | Batas |
|---|---|---|
| FREE | model role FREE (+ trial: Claude Haiku 4.5 ×3, Deepseek V4 Flash 0731 ×1) | 1300 Dinar/hari |
| PRO | FREE + PRO | tanpa batas Dinar |
| MAX | semua | tanpa batas Dinar |

`/tier free|pro|max` · `/models` (170 model, 🔒 = terkunci) · `/status`.
Hitungan: **1 request = 65 Dinar** (1300/65 = 20 request/hari); tiap kelipatan 8000 token dalam satu request dihitung +1 request
(`dinar_token_unit` di `config.json`). Reset **00:00 waktu setempat**: zona waktu/provinsi dideteksi dari IP (ipwho.is, cache 24 jam)
atau isi `"timezone": "Asia/Jakarta"` di `~/.codinx/config.json`. Cek dengan `/location`.

## Catatan keamanan
- Brankas kunci mengikat ke mesin ini (machine-id); root di mesin yang sama tetap bisa membukanya.
- `.seed` di zip berisi key **plaintext** sampai run pertama → hapus zip setelah dipasang, dan ganti key bila zip pernah dibagikan.
- Pembatasan paket/Dinar berjalan di sisi klien (root bisa mengubahnya). Untuk penegakan sungguhan, terapkan juga di proxy.

## Struktur
    bin/codinx  cx/*.py  data/models.json  skills/  commands/  install.sh  uninstall.sh  package.json
Data: `~/.codinx/` (config.json, .key.enc, sessions/, memory.json, usage.json, geo.json, skills/, commands/)

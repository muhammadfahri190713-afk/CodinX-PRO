"""Skills (SKILL.md + frontmatter), progressive disclosure: hanya nama+deskripsi masuk prompt."""
import os
import re

from . import config

PKG_SKILLS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "skills")


def roots(cwd):
    return [PKG_SKILLS, os.path.join(config.HOME, "skills"), os.path.join(cwd, ".codinx", "skills")]


def parse(text):
    meta, body = {}, text
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n?(.*)$", text, re.S)
    if m:
        for ln in m.group(1).splitlines():
            if ":" in ln:
                k, v = ln.split(":", 1)
                meta[k.strip().lower()] = v.strip().strip("'\"")
        body = m.group(2)
    return meta, body


def discover(cwd):
    found = {}
    for root in roots(cwd):
        if not os.path.isdir(root):
            continue
        for d in sorted(os.listdir(root)):
            f = os.path.join(root, d, "SKILL.md")
            if os.path.isfile(f):
                try:
                    with open(f, encoding="utf-8") as fh:
                        meta, _ = parse(fh.read())
                except OSError:
                    continue
                name = meta.get("name") or d
                found[name] = {"name": name, "description": meta.get("description", ""), "path": f, "dir": os.path.join(root, d)}
    return found


def load(name, cwd):
    sk = discover(cwd).get(name)
    if not sk:
        return None
    with open(sk["path"], encoding="utf-8") as fh:
        _, body = parse(fh.read())
    extra = [x for x in sorted(os.listdir(sk["dir"])) if x != "SKILL.md"]
    tail = ("\n\n[File pendukung di %s: %s]" % (sk["dir"], ", ".join(extra))) if extra else ""
    return body.strip() + tail


def index_block(cwd):
    sk = discover(cwd)
    if not sk:
        return ""
    return "\n".join(f"- {s['name']}: {s['description']}" for s in sk.values())
